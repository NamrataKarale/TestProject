package com.examples.category.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.examples.category.model.Category;
@Repository
public interface CategoryRepository extends JpaRepository<Category,Integer> {

	List<Category> findAll();

	List<Category> findByName(String name);
		
	
}
