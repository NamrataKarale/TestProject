package com.examples;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
